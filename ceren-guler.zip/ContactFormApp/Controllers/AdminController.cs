using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ContactFormApp.Data;
using ContactFormApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ContactFormApp.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (username == "ceren" && password == "ceren")
            {
                // Oturum açma bilgilerini sakla
                TempData["IsLoggedIn"] = true;
                return RedirectToAction("Messages");
            }

            ViewBag.Error = "Kullanıcı adı veya şifre hatalı!";
            return View("Index");
        }

        public IActionResult Messages()
        {
            // Oturum kontrolü
            if (TempData["IsLoggedIn"] == null)
            {
                return RedirectToAction("Index");
            }

            // Yeniden oturum saklama (sayfa yenilenirse kaybolmaması için)
            TempData.Keep("IsLoggedIn");

            // Tüm mesajları getir
            var messages = _context.IletisimFormu.OrderByDescending(m => m.Tarih).ToList();
            return View(messages);
        }

        public IActionResult Logout()
        {
            TempData.Remove("IsLoggedIn");
            return RedirectToAction("Index");
        }
    }
}