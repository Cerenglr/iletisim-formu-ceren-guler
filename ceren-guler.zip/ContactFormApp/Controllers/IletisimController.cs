using System;
using System.Threading.Tasks;
using ContactFormApp.Data;
using ContactFormApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ContactFormApp.Controllers
{
    public class IletisimController : Controller
    {
    private readonly ApplicationDbContext _context;
private readonly ILogger<IletisimController> _logger;

public IletisimController(ApplicationDbContext context, ILogger<IletisimController> logger)
{
    _context = context;
    _logger = logger;
}
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Gonder(IletisimFormu iletisimFormu)
        {
            if (ModelState.IsValid)
            {
                iletisimFormu.Tarih = DateTime.Now;
                _context.Add(iletisimFormu);
                await _context.SaveChangesAsync();
                
                // AJAX isteği ise
                if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
                {
                    return Json(new { success = true, message = "Mesajınız başarıyla gönderildi!" });
                }
                
                TempData["SuccessMessage"] = "Mesajınız başarıyla gönderildi!";
                return RedirectToAction(nameof(Index));
            }

            // AJAX isteği ise
            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = false, message = "Form bilgilerinde hata var, lütfen kontrol ediniz." });
            }
            
            return View("Index", iletisimFormu);
        }
    }
}