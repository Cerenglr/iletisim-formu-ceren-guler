using ContactFormApp.Models;
using Microsoft.EntityFrameworkCore;

namespace ContactFormApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<IletisimFormu> IletisimFormu { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IletisimFormu>().ToTable("iletisim_formu");
            
            // Kolon isimlerini manuel olarak eşleştirme
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Id).HasColumnName("id");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Ad).HasColumnName("ad");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Soyad).HasColumnName("soyad");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Email).HasColumnName("email");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Telefon).HasColumnName("telefon");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Konu).HasColumnName("konu");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Mesaj).HasColumnName("mesaj");
            modelBuilder.Entity<IletisimFormu>()
                .Property(f => f.Tarih).HasColumnName("tarih");
        }
    }
}