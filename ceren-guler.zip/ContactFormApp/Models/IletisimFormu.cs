using System;
using System.ComponentModel.DataAnnotations;

namespace ContactFormApp.Models
{
    public class IletisimFormu
    {
        public int Id { get; set; }
        
        [Required(ErrorMessage = "Ad alanı zorunludur")]
        [Display(Name = "Adınız")]
        public string? Ad { get; set; }
        
        [Required(ErrorMessage = "Soyad alanı zorunludur")]
        [Display(Name = "Soyadınız")]
        public string? Soyad { get; set; }
        
        [Required(ErrorMessage = "E-posta alanı zorunludur")]
        [EmailAddress(ErrorMessage = "Geçerli bir e-posta adresi giriniz")]
        [Display(Name = "E-posta")]
        public string? Email { get; set; }
        
        [Phone(ErrorMessage = "Geçerli bir telefon numarası giriniz")]
        [Display(Name = "Telefon")]
        public string? Telefon { get; set; }
        
        [Required(ErrorMessage = "Konu alanı zorunludur")]
        [Display(Name = "Konu")]
        public string? Konu { get; set; }
        
        [Required(ErrorMessage = "Mesaj alanı zorunludur")]
        [Display(Name = "Mesajınız")]
        public string? Mesaj { get; set; }
        
        public DateTime Tarih { get; set; } = DateTime.Now;
    }
}