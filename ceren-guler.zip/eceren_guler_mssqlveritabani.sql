SELECT * FROM iletisim_formu;
GO